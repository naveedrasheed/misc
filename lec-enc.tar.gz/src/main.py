from config_utils import load_and_update_config
from dataset import load_dataset
import tensorflow as _tf

# Compatibility shim: some object_detection versions expect
# tf.keras.layers.experimental.SyncBatchNormalization to exist.
# Without modifying site-packages, create the attribute if missing by
# aliasing the available SyncBatchNormalization or falling back to
# BatchNormalization (less ideal but avoids import errors).
try:
    _ = _tf.keras.layers.experimental.SyncBatchNormalization
except Exception:
    if hasattr(_tf.keras.layers, 'SyncBatchNormalization'):
        # create experimental namespace if necessary
        if not hasattr(_tf.keras.layers, 'experimental'):
            _tf.keras.layers.experimental = type('experimental', (), {})()
        _tf.keras.layers.experimental.SyncBatchNormalization = _tf.keras.layers.SyncBatchNormalization
    else:
        # final fallback
        if not hasattr(_tf.keras.layers, 'experimental'):
            _tf.keras.layers.experimental = type('experimental', (), {})()
        _tf.keras.layers.experimental.SyncBatchNormalization = _tf.keras.layers.BatchNormalization

from model_utils import build_model, get_optimizer
from train import train_model
from export_model import export_model

BASE_CONFIG = "config/pipeline.config"
MODEL_DIR = "training_dir"
CHECKPOINT_PATH = "ssd_mobilenet_v2_320x320_coco17_tpu-8/checkpoint/ckpt-0"
TRAIN_RECORD = "data/voc2012_boats_train.record"
VAL_RECORD = "data/voc2012_boats_val.record"
LABEL_MAP = "data/boat_label_map.pbtxt"
BATCH_SIZE = 8
NUM_CLASSES = 1
EPOCHS = 10

if __name__ == "__main__":
    pipeline_config, updated_config_path = load_and_update_config(
        base_config_path=BASE_CONFIG,
        model_dir=MODEL_DIR,
        checkpoint_path=CHECKPOINT_PATH,
        train_record=TRAIN_RECORD,
        val_record=VAL_RECORD,
        label_map=LABEL_MAP,
        batch_size=BATCH_SIZE,
        num_classes=NUM_CLASSES
    )
    train_dataset = load_dataset(TRAIN_RECORD, batch_size=BATCH_SIZE)
    model = build_model(pipeline_config, CHECKPOINT_PATH)
    optimizer = get_optimizer()
    train_model(model, optimizer, train_dataset, epochs=EPOCHS)
    export_model(updated_config_path, MODEL_DIR, "exported_model")
