# This is the final one
# 
import tensorflow as tf
import numpy as np
import cv2
import os
import tflite_runtime.interpreter as tflite
from base_path import base_dir_path
from labels import label2string

MODEL_PATH = base_dir_path + "ssd_mobilenet_v2_320x320_coco17_tpu-8/saved_model/"
TFLITE_MODEL_PATH = base_dir_path + "ssd_mobilenet_v2_320x320_coco17_tpu-8/ssd_mobilenet_v2_320x320_quant.tflite"

def representative_data_gen():
    dataset_path = base_dir_path + "coco2017/val2017/"
    image_files = [f for f in os.listdir(dataset_path) 
                  if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    for img_name in image_files:
        img_path = os.path.join(dataset_path, img_name)
        img = cv2.imread(img_path)
        if img is None:
            continue
        img = cv2.resize(img, (320, 320))
        img = np.expand_dims(img, axis=0)
        yield [img.astype(np.uint8)]
        print(f"Processed image: {img_name}")

# Load the model
model = tf.saved_model.load(MODEL_PATH)
infer = model.signatures['serving_default']

# Wrap with fixed input shape
@tf.function(input_signature=[tf.TensorSpec([1, 320, 320, 3], tf.uint8, name='input_tensor')])
def wrapped_model(input_tensor):
    return infer(input_tensor)

concrete_func = wrapped_model.get_concrete_function()

# Create converter
converter = tf.lite.TFLiteConverter.from_concrete_functions([concrete_func])
converter.optimizations = [tf.lite.Optimize.DEFAULT]
converter.representative_dataset = representative_data_gen
converter.target_spec.supported_ops = [
    tf.lite.OpsSet.TFLITE_BUILTINS,
    tf.lite.OpsSet.TFLITE_BUILTINS_INT8,
    tf.lite.OpsSet.SELECT_TF_OPS
]
converter.inference_input_type = tf.uint8
# converter.inference_output_type = tf.uint8
converter.allow_custom_ops = True

# Convert and save
tflite_model = converter.convert()
with open(TFLITE_MODEL_PATH, 'wb') as f:
    f.write(tflite_model)

print(f"Quantized model saved to {TFLITE_MODEL_PATH}")

cv2.namedWindow("image", cv2.WINDOW_NORMAL)
cv2.resizeWindow("image", 1280, 720)

# Verify input shape
interpreter = tflite.Interpreter(model_path=TFLITE_MODEL_PATH)
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()
print(f"Input shape after conversion: {input_details[0]['shape']}")
print(f"Input type: {input_details[0]['dtype']}")
print(f"Output details: {output_details}")

# Load and preprocess input image
img_path = "/home/gujjar/wsl_workspace/eiq-example/object_detection/cars0.bmp"
frame = cv2.imread(img_path)
img = cv2.resize(frame, (320, 320))
img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
input_data = np.expand_dims(img_rgb, axis=0).astype(np.uint8)

# Run inference
interpreter.set_tensor(input_details[0]['index'], input_data)
interpreter.invoke()

# Get output tensors (update indices as needed based on output_details)
boxes = interpreter.get_tensor(output_details[1]['index'])[0]  # detection_boxes
classes = interpreter.get_tensor(output_details[2]['index'])[0]  # detection_classes
scores = interpreter.get_tensor(output_details[4]['index'])[0]  # detection_scores
num = interpreter.get_tensor(output_details[5]['index'])[0]  # num_detections

# Draw results
for i in range(int(num)):
    if scores[i] > 0.5:  # confidence threshold
        ymin, xmin, ymax, xmax = boxes[i]
        (left, top, right, bottom) = (int(xmin * frame.shape[1]), int(ymin * frame.shape[0]),
                                      int(xmax * frame.shape[1]), int(ymax * frame.shape[0]))
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)

        if int(classes[i]) - 1 in label2string:
             label = label2string[int(classes[i]) - 1]
        else:
             label = "Unknown"
        label = f"{label}: {scores[i]:.2f}"
        cv2.putText(frame, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)

# Show result
cv2.imshow("Result", frame)
cv2.waitKey(0)
cv2.destroyAllWindows()
