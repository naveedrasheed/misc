import tensorflow as tf
from object_detection.builders import model_builder

def build_model(pipeline_config, checkpoint_path):
    """
    Builds and loads SSD MobileNet detection model.
    
    Args:
        pipeline_config: protobuf object from pipeline.config
        checkpoint_path (str): path to pretrained checkpoint prefix (without .index)
    
    Returns:
        detection_model: tf.Module
    """
    detection_model = model_builder.build(
        model_config=pipeline_config.model, is_training=True
    )

    # Restore checkpoint
    ckpt = tf.train.Checkpoint(model=detection_model)
    ckpt.restore(checkpoint_path).expect_partial()
    
    return detection_model

def get_optimizer(learning_rate=0.004, momentum=0.9):
    """
    Returns SGD optimizer with momentum.
    """
    return tf.keras.optimizers.SGD(learning_rate=learning_rate, momentum=momentum)

def get_train_step_fn(model, optimizer):
    """
    Returns a tf.function wrapped training step for custom training loop.
    """
    @tf.function
    def train_step(images, labels):
        with tf.GradientTape() as tape:
            # Preprocess images
            preprocessed_images, true_shapes = model.preprocess(images)
            # Forward pass
            prediction_dict = model.predict(preprocessed_images, true_shapes)
            # Compute losses
            losses = model.loss(prediction_dict, labels)
            total_loss = tf.add_n(list(losses.values()))  # sum all losses

        # Compute gradients and update weights
        gradients = tape.gradient(total_loss, model.trainable_variables)
        optimizer.apply_gradients(zip(gradients, model.trainable_variables))

        return total_loss

    return train_step
