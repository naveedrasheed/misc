from model_utils import get_train_step_fn

def train_model(model, optimizer, train_dataset, epochs=10, log_interval=50):
    train_step_fn = get_train_step_fn(model, optimizer)
    for epoch in range(epochs):
        print(f"\n=== Epoch {epoch+1}/{epochs} ===")
        for step, batch in enumerate(train_dataset):
            images = batch['image']
            labels = {
                'groundtruth_boxes': batch['groundtruth_boxes'],
                'groundtruth_classes': batch['groundtruth_classes'],
            }
            print("Labels keys:", labels.keys()) # <-- Add this line to see what fields are available
            loss = train_step_fn(images, labels)
            if step % log_interval == 0:
                print(f"Step {step}: Loss = {loss.numpy():.4f}")
