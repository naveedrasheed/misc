import os
import tensorflow as tf
from object_detection.protos import pipeline_pb2
from object_detection.protos import train_pb2
from google.protobuf import text_format

def load_and_update_config(
        base_config_path,
        model_dir,
        checkpoint_path,
        train_record,
        val_record,
        label_map,
        batch_size=16,
        num_classes=1):

    # Add this debug code temporarily
    print("Available attributes in pipeline_pb2:")
    print([attr for attr in dir(pipeline_pb2) if not attr.startswith('_')])
    print("Available attributes in train_pb2:")
    print([attr for attr in dir(train_pb2) if not attr.startswith('_')])

    # Load base config into protobuf
    pipeline_config = pipeline_pb2.TrainEvalPipelineConfig()
    with tf.io.gfile.GFile(base_config_path, "r") as f:
        text_format.Merge(f.read(), pipeline_config)

    # === Update key fields ===
    pipeline_config.model.ssd.num_classes = num_classes

    pipeline_config.train_config.fine_tune_checkpoint = checkpoint_path
    pipeline_config.train_config.fine_tune_checkpoint_type = "detection"
    pipeline_config.train_config.fine_tune_checkpoint_version = train_pb2.V2
    pipeline_config.train_config.batch_size = batch_size

    # Training dataset
    pipeline_config.train_input_reader.label_map_path = label_map
    pipeline_config.train_input_reader.tf_record_input_reader.input_path[:] = [train_record]

    # Validation dataset
    pipeline_config.eval_input_reader[0].label_map_path = label_map
    pipeline_config.eval_input_reader[0].tf_record_input_reader.input_path[:] = [val_record]

    # === Save updated config ===
    os.makedirs(model_dir, exist_ok=True)
    config_path = os.path.join(model_dir, "pipeline.config")
    with tf.io.gfile.GFile(config_path, "w") as f:
        f.write(text_format.MessageToString(pipeline_config))

    return pipeline_config, config_path
