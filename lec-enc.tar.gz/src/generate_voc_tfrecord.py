#!/usr/bin/env python3
"""
generate_voc_tfrecord.py

Convert VOC XML annotations + JPEGImages into a TFRecord suitable for
TensorFlow Object Detection API training/evaluation.

Usage:
  python generate_voc_tfrecord.py \
    --images_dir /path/to/JPEGImages \
    --annotations_dir /path/to/Annotations \
    --output_path /path/to/output.record \
    --labels /path/to/labels.txt

labels.txt should contain one class name per line, e.g.:
  boat

Dependencies: tensorflow (or tensorflow-cpu) and Pillow
"""

import os
import argparse
import xml.etree.ElementTree as ET
from PIL import Image
import tensorflow as tf


def load_label_map(labels_path):
    """Load a simple labels file (one name per line) into dict{name: id}.
    IDs start at 1.
    """
    label_map = {}
    with open(labels_path, 'r', encoding='utf-8') as f:
        for idx, line in enumerate(f, start=1):
            name = line.strip()
            if not name:
                continue
            label_map[name] = idx
    return label_map


def load_label_map_from_pbtxt(pbtxt_path):
    """Parse a TF-style label_map.pbtxt into a dict{name: id}.

    It prefers `display_name` then `name` as the human-readable label.
    """
    import re

    items = {}
    with open(pbtxt_path, 'r', encoding='utf-8') as f:
        content = f.read()

    blocks = re.findall(r'item\s*{([^}]*)}', content, re.DOTALL)
    for b in blocks:
        id_match = re.search(r'id\s*:\s*(\d+)', b)
        dn_match = re.search(r'display_name\s*:\s*"([^"]+)"', b)
        name_match = re.search(r'name\s*:\s*"([^"]+)"', b)
        if id_match:
            idx = int(id_match.group(1))
            label = None
            if dn_match:
                label = dn_match.group(1)
            elif name_match:
                label = name_match.group(1)
            if label:
                items[label] = idx
    return items


def int64_feature(value):
    return tf.train.Feature(int64_list=tf.train.Int64List(value=[value] if isinstance(value, int) else value))


def bytes_feature(value):
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))


def float_list_feature(values):
    return tf.train.Feature(float_list=tf.train.FloatList(value=values))


def bytes_list_feature(values):
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=values))


def create_tf_example(annotation_path, image_path, label_map):
    tree = ET.parse(annotation_path)
    root = tree.getroot()

    filename = root.find('filename').text

    # Read image
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")
    with open(image_path, 'rb') as f:
        encoded_jpg = f.read()

    # Image size from XML (fall back to PIL if missing)
    size = root.find('size')
    if size is not None and size.find('width') is not None:
        width = int(size.find('width').text)
        height = int(size.find('height').text)
    else:
        im = Image.open(image_path)
        width, height = im.size

    xmins = []  # List of normalized left x
    xmaxs = []
    ymins = []
    ymaxs = []
    classes_text = []
    classes = []

    for obj in root.findall('object'):
        name = obj.find('name').text
        if name not in label_map:
            # Skip unknown classes
            continue
        bndbox = obj.find('bndbox')
        xmin = float(bndbox.find('xmin').text) / width
        ymin = float(bndbox.find('ymin').text) / height
        xmax = float(bndbox.find('xmax').text) / width
        ymax = float(bndbox.find('ymax').text) / height

        xmins.append(xmin)
        xmaxs.append(xmax)
        ymins.append(ymin)
        ymaxs.append(ymax)
        classes_text.append(name.encode('utf8'))
        classes.append(label_map[name])

    if not classes:
        return None  # no known objects in this image

    feature_dict = {
        'image/height': int64_feature(height),
        'image/width': int64_feature(width),
        'image/filename': bytes_feature(filename.encode('utf8')),
        'image/source_id': bytes_feature(filename.encode('utf8')),
        'image/encoded': bytes_feature(encoded_jpg),
        'image/format': bytes_feature(b'jpg'),
        'image/object/bbox/xmin': float_list_feature(xmins),
        'image/object/bbox/xmax': float_list_feature(xmaxs),
        'image/object/bbox/ymin': float_list_feature(ymins),
        'image/object/bbox/ymax': float_list_feature(ymaxs),
        'image/object/class/text': bytes_list_feature(classes_text),
        'image/object/class/label': int64_feature(classes),
    }

    example = tf.train.Example(features=tf.train.Features(feature=feature_dict))
    return example


def main():
    parser = argparse.ArgumentParser(description='Generate TFRecord from VOC XMLs')
    parser.add_argument('--images_dir', required=True, help='Path to JPEGImages folder')
    parser.add_argument('--annotations_dir', required=True, help='Path to Annotations folder')
    parser.add_argument('--output_path', required=True, help='Output TFRecord path')
    parser.add_argument('--labels', required=False, help='Path to labels.txt (one class per line)')
    parser.add_argument('--label_map', required=False, help='Path to label_map.pbtxt (TF Object Detection API format)')

    args = parser.parse_args()

    # Load label mapping: prefer label_map.pbtxt if provided
    if args.label_map:
        label_map = load_label_map_from_pbtxt(args.label_map)
    elif args.labels:
        label_map = load_label_map(args.labels)
    else:
        raise ValueError('Provide --labels or --label_map')

    if not label_map:
        raise ValueError('No labels found')

    xml_files = [f for f in sorted(os.listdir(args.annotations_dir)) if f.lower().endswith('.xml')]
    writer = tf.io.TFRecordWriter(args.output_path)

    written = 0
    skipped = 0
    for xml in xml_files:
        ann_path = os.path.join(args.annotations_dir, xml)
        # Determine image filename from XML
        try:
            tree = ET.parse(ann_path)
        except ET.ParseError:
            print(f"Skipping malformed XML: {ann_path}")
            skipped += 1
            continue
        root = tree.getroot()
        filename_tag = root.find('filename')
        if filename_tag is None or not filename_tag.text:
            print(f"Skipping XML with no filename: {ann_path}")
            skipped += 1
            continue
        image_path = os.path.join(args.images_dir, filename_tag.text)

        try:
            tf_example = create_tf_example(ann_path, image_path, label_map)
        except FileNotFoundError:
            print(f"Image not found for annotation, skipping: {image_path}")
            skipped += 1
            continue

        if tf_example is None:
            skipped += 1
            continue

        writer.write(tf_example.SerializeToString())
        written += 1

    writer.close()
    print(f"Wrote {written} examples to {args.output_path} (skipped {skipped})")


if __name__ == '__main__':
    '''
    python generate_voc_tfrecord.py \
        --images_dir /mnt/c/Users/navee/Downloads/VOC2012/VOC2012_Boats_Train/JPEGImages \
        --annotations_dir /mnt/c/Users/navee/Downloads/VOC2012/VOC2012_Boats_Train/Annotations \
        --output_path ../data/voc2012_boats_train.record \
        --label_map ../data/boat_label_map.pbtxt

    for validation set:
    python generate_voc_tfrecord.py \
        --images_dir /mnt/c/Users/navee/Downloads/VOC2012/VOC2012_Boats_Val/JPEGImages \
        --annotations_dir /mnt/c/Users/navee/Downloads/VOC2012/VOC2012_Boats_Val/Annotations \
        --output_path ../data/voc2012_boats_val.record \
        --label_map ../data/boat_label_map.pbtxt
    '''
    main()
