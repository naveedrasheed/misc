import os
import xml.etree.ElementTree as ET
import shutil
import random

BASE_DIR = "/mnt/c/Users/navee/Downloads/VOC2012/"
IMG_DIR = os.path.join(BASE_DIR, "VOC2012_train_val/JPEGImages")
ANN_DIR = os.path.join(BASE_DIR, "VOC2012_train_val/Annotations")
TRAIN_IMG_DIR = os.path.join(BASE_DIR, "VOC2012_Boats_Train/JPEGImages")
TRAIN_ANN_DIR = os.path.join(BASE_DIR, "VOC2012_Boats_Train/Annotations")
VAL_IMG_DIR = os.path.join(BASE_DIR, "VOC2012_Boats_Val/JPEGImages")
VAL_ANN_DIR = os.path.join(BASE_DIR, "VOC2012_Boats_Val/Annotations")

# Set 80/20 split (20% validation)
SPLIT_SEED = int(os.environ.get('SPLIT_SEED', 42))
VAL_FRACTION = 0.2  # Fixed 20% for validation

# Create output directories
os.makedirs(TRAIN_IMG_DIR, exist_ok=True)
os.makedirs(TRAIN_ANN_DIR, exist_ok=True)
os.makedirs(VAL_IMG_DIR, exist_ok=True)
os.makedirs(VAL_ANN_DIR, exist_ok=True)

# Gather annotation files that contain at least one boat
boat_ann_files = []
for ann_file in sorted(os.listdir(ANN_DIR)):
    if not ann_file.lower().endswith('.xml'):
        continue
    ann_path = os.path.join(ANN_DIR, ann_file)
    try:
        tree = ET.parse(ann_path)
    except ET.ParseError:
        # skip malformed xml
        continue
    root = tree.getroot()
    objects = root.findall('object')
    boat_objs = [obj for obj in objects if obj.find('name').text.lower() == 'boat']
    if boat_objs:
        boat_ann_files.append(ann_file)

print(f"Found {len(boat_ann_files)} files with boat annotations")

# Shuffle with reproducible seed, then split based on VAL_FRACTION
random.seed(SPLIT_SEED)
random.shuffle(boat_ann_files)

# Determine indices for validation set (20% for validation)
total_boats = len(boat_ann_files)
val_count = max(1, int(total_boats * VAL_FRACTION))
val_indices = set(range(val_count))

print(f"Splitting: {total_boats - val_count} for training, {val_count} for validation")

boat_count = 0
copied_train = copied_val = 0

for i, ann_file in enumerate(boat_ann_files):
    ann_path = os.path.join(ANN_DIR, ann_file)
    tree = ET.parse(ann_path)
    root = tree.getroot()
    objects = root.findall('object')
    boat_objs = [obj for obj in objects if obj.find('name').text.lower() == 'boat']

    # Remove non-boat objects
    for obj in list(objects):
        if obj not in boat_objs:
            root.remove(obj)

    # Decide whether this boat example goes to val or train
    boat_count += 1
    to_val = (i in val_indices)

    if to_val:
        out_ann_path = os.path.join(VAL_ANN_DIR, ann_file)
        out_img_dir = VAL_IMG_DIR
    else:
        out_ann_path = os.path.join(TRAIN_ANN_DIR, ann_file)
        out_img_dir = TRAIN_IMG_DIR

    # Save filtered XML
    tree.write(out_ann_path)

    # Copy image
    filename_tag = root.find('filename')
    if filename_tag is None or filename_tag.text is None:
        print(f"Warning: No filename found in annotation {ann_file}, skipping image copy.")
        continue
    img_filename = filename_tag.text
    img_path = os.path.join(IMG_DIR, img_filename)
    out_img_path = os.path.join(out_img_dir, img_filename)
    if os.path.exists(img_path):
        shutil.copy(img_path, out_img_path)
        if to_val:
            copied_val += 1
        else:
            copied_train += 1
    else:
        print(f"Warning: Image file {img_path} does not exist, skipping copy.")

print(f"Total boat annotations processed: {boat_count}")
print(f"Copied to train: {copied_train}, copied to val: {copied_val}")
print(f"Split ratio: {copied_train/(copied_train+copied_val):.1%} train, {copied_val/(copied_train+copied_val):.1%} validation")
