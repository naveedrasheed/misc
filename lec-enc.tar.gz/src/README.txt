# 1) Install system dependency (protoc)
sudo apt-get update
sudo apt-get install -y protobuf-compiler

# 2) Clone the TensorFlow models repo (or update if you already have it)
cd ~
git clone https://github.com/tensorflow/models.git
cd models

# 3) Compile object_detection protos
cd research
protoc object_detection/protos/*.proto --python_out=.

# 4) Add research and slim to PYTHONPATH for the current shell
export PYTHONPATH=$PYTHONPATH:`pwd`:`pwd`/slim

# Optional: persist the PYTHONPATH by adding to ~/.bashrc
echo 'export PYTHONPATH=$PYTHONPATH:~/models/research:~/models/research/slim' >> ~/.bashrc

# 5) (Optional but useful) Install the object_detection package locally (some setups expect it)
# This installs the package into your current environment.
pip install --upgrade pip
cd ~/models/research
pip install .


cd ~/wsl_workspace/tf_models/research   # or the absolute path to your models/research
# 1) Compile protos
protoc object_detection/protos/*.proto --python_out=.

# 2) Copy the TF2 setup script and install
cp object_detection/packages/tf2/setup.py .
python -m pip install .


cd ~/wsl_workspace/tf_models/research
protoc object_detection/protos/*.proto --python_out=.
export PYTHONPATH=$PYTHONPATH:`pwd`:`pwd`/slim
# now imports should work in this shell:
python -c "from object_detection.protos import pipeline_pb2; print('OK')"

--

python -c "import tensorflow as tf; print('Num GPUs Available: ', len(tf.config.list_physical_devices('GPU')))"
python -c "import numpy as np; print(f'NumPy {np.__version__} OK')"
python -c "import tensorflow as tf; print(f'TensorFlow {tf.__version__} OK')"
python -c "import cv2; print(f'OpenCV {cv2.__version__} OK')"