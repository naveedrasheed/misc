import os
from object_detection import exporter_lib_v2

def export_model(pipeline_config_path, model_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    exporter_lib_v2.export_inference_graph(
        input_type='image_tensor',
        pipeline_config_path=pipeline_config_path,
        trained_checkpoint_dir=model_dir,
        output_directory=output_dir
    )
    print(f"Model successfully exported to {output_dir}")
