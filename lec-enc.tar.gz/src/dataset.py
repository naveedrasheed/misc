import tensorflow as tf

def parse_tfrecord(example):
    """
    Parses a single TFRecord example into image, boxes, and classes.
    """
    feature_description = {
        'image/encoded': tf.io.FixedLenFeature([], tf.string),
        'image/object/bbox/xmin': tf.io.VarLenFeature(tf.float32),
        'image/object/bbox/xmax': tf.io.VarLenFeature(tf.float32),
        'image/object/bbox/ymin': tf.io.VarLenFeature(tf.float32),
        'image/object/bbox/ymax': tf.io.VarLenFeature(tf.float32),
        'image/object/class/label': tf.io.VarLenFeature(tf.int64),
    }
    example = tf.io.parse_single_example(example, feature_description)

    # Decode image
    image = tf.image.decode_jpeg(example['image/encoded'], channels=3)
    image = tf.image.convert_image_dtype(image, tf.float32)  # [0,1]

    # Bounding boxes [N, 4] in [ymin, xmin, ymax, xmax] format
    xmin = tf.sparse.to_dense(example['image/object/bbox/xmin'])
    xmax = tf.sparse.to_dense(example['image/object/bbox/xmax'])
    ymin = tf.sparse.to_dense(example['image/object/bbox/ymin'])
    ymax = tf.sparse.to_dense(example['image/object/bbox/ymax'])
    boxes = tf.stack([ymin, xmin, ymax, xmax], axis=1)

    # Classes
    classes = tf.sparse.to_dense(example['image/object/class/label'])

    return {
        'image': image,
        'groundtruth_boxes': boxes,
        'groundtruth_classes': classes
    }

def load_dataset(tfrecord_path, batch_size=8, shuffle=True):
    """
    Loads TFRecord dataset with padding for variable number of boxes.
    """
    if isinstance(tfrecord_path, str):
        tfrecord_path = [tfrecord_path]

    raw_dataset = tf.data.TFRecordDataset(tfrecord_path)
    dataset = raw_dataset.map(parse_tfrecord, num_parallel_calls=tf.data.AUTOTUNE)

    if shuffle:
        dataset = dataset.shuffle(buffer_size=512)

    dataset = dataset.padded_batch(
        batch_size,
        padded_shapes={
            'image': [None, None, 3],        # variable H,W
            'groundtruth_boxes': [None, 4],  # variable number of boxes
            'groundtruth_classes': [None],   # variable number of labels
        },
        padding_values={
            'image': tf.constant(0.0, dtype=tf.float32),
            'groundtruth_boxes': tf.constant(0.0, dtype=tf.float32),
            'groundtruth_classes': tf.constant(0, dtype=tf.int64),  # fix dtype mismatch
        },
        drop_remainder=True
    )

    dataset = dataset.prefetch(tf.data.AUTOTUNE)
    return dataset
