import tensorflow as tf
import numpy as np
import cv2
import os
import tflite_runtime.interpreter as tflite
from base_path import base_dir_path
from labels import label2string
import os
import tensorflow as tf
from object_detection.utils import config_util
from object_detection.protos import pipeline_pb2
from google.protobuf import text_format
from object_detection.builders import model_builder


MODEL_PATH = base_dir_path + "ssd_mobilenet_v2_320x320_coco17_tpu-8/saved_model/"
TRAINED_MODEL_PATH = base_dir_path + "ssd_mobilenet_v2_320x320_coco17_tpu-8-trained/saved_model/"

# Paths
pipeline_config = "ssd_mobilenet_v2_320x320_coco17_tpu-8/pipeline.config"
model_dir = "training_dir"
fine_tune_checkpoint = "ssd_mobilenet_v2_320x320_coco17_tpu-8/checkpoint/ckpt-0"

train_record = "data/voc2012_train.record"
val_record = "data/voc2012_val.record"
label_map = "mscoco_label_map.pbtxt"

# Load pipeline config
configs = config_util.get_configs_from_pipeline_file(pipeline_config)
pipeline_config = pipeline_pb2.TrainEvalPipelineConfig()
with tf.io.gfile.GFile(pipeline_config, "r") as f:
    text_format.Merge(f.read(), pipeline_config)

# Modify fields
pipeline_config.model.ssd.num_classes = 90   # keep COCO classes
pipeline_config.train_config.fine_tune_checkpoint = fine_tune_checkpoint
pipeline_config.train_config.fine_tune_checkpoint_type = "detection"
pipeline_config.train_config.batch_size = 16
pipeline_config.train_config.optimizer.momentum_optimizer.learning_rate.cosine_decay_learning_rate.learning_rate_base = 0.04

pipeline_config.train_input_reader.label_map_path = label_map
pipeline_config.train_input_reader.tf_record_input_reader.input_path[:] = [train_record]

pipeline_config.eval_input_reader[0].label_map_path = label_map
pipeline_config.eval_input_reader[0].tf_record_input_reader.input_path[:] = [val_record]

# Save new pipeline config
config_text = text_format.MessageToString(pipeline_config)
with tf.io.gfile.GFile(os.path.join(model_dir, "pipeline.config"), "wb") as f:
    f.write(config_text.encode("utf-8"))
print("Modified pipeline config and saved to", os.path.join(model_dir, "pipeline.config"))

# Build model
detection_model = model_builder.build(
    model_config=pipeline_config.model, is_training=True)

# Restore checkpoint
ckpt = tf.train.Checkpoint(model=detection_model)
ckpt.restore(fine_tune_checkpoint).expect_partial()
print("Model built and checkpoint restored from", fine_tune_checkpoint)

def get_model_train_step_function(model, optimizer, batch_size):

    @tf.function
    def train_step_fn(features, labels):
        with tf.GradientTape() as tape:
            preprocessed_images, true_shapes = model.preprocess(features)
            prediction_dict = model.predict(preprocessed_images, true_shapes)
            losses = model.loss(prediction_dict, labels)
            total_loss = losses['Loss/localization_loss'] + losses['Loss/classification_loss']

        gradients = tape.gradient(total_loss, model.trainable_variables)
        optimizer.apply_gradients(zip(gradients, model.trainable_variables))
        return total_loss

    return train_step_fn
optimizer = tf.keras.optimizers.SGD(learning_rate=0.04, momentum=0.9)

def parse_tfrecord(example):
    # TF Object Detection API already has parsers
    from object_detection.data_decoders.tf_example_decoder import TfExampleDecoder
    decoder = TfExampleDecoder()
    return decoder.decode(example)

def load_dataset(tfrecord_path, batch_size=16):
    raw_dataset = tf.data.TFRecordDataset(tfrecord_path)
    decoder = parse_tfrecord
    dataset = raw_dataset.map(decoder, num_parallel_calls=tf.data.AUTOTUNE)
    dataset = dataset.shuffle(512).batch(batch_size).prefetch(tf.data.AUTOTUNE)
    return dataset

train_dataset = load_dataset(train_record, batch_size=16)
val_dataset = load_dataset(val_record, batch_size=16)

optimizer = tf.keras.optimizers.SGD(learning_rate=0.004, momentum=0.9)
train_step_fn = get_model_train_step_function(detection_model, optimizer, batch_size=16)

EPOCHS = 10
for epoch in range(EPOCHS):
    print(f"Epoch {epoch+1}/{EPOCHS}")
    for step, (images, labels) in enumerate(train_dataset):
        loss = train_step_fn(images, labels)
        if step % 50 == 0:
            print(f"Step {step}: Loss = {loss.numpy():.4f}")
